/**
 * Provides the Spectral Curve API of Image4J.
 */
package org.macroing.image4j.spectralcurve;