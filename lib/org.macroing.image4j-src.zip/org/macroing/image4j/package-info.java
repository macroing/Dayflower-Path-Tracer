/**
 * Provides the core APIs of Image4J.
 */
package org.macroing.image4j;