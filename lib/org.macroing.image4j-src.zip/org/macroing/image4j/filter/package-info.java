/**
 * Provides the Filter API of Image4J.
 */
package org.macroing.image4j.filter;