/**
 * Provides the Film API of Image4J.
 */
package org.macroing.image4j.film;